const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
require("dotenv").config();

const strayRoutes = require('./routes/stray.routes.js');
const doctorRoutes = require('./routes/doctor.routes.js');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());    

mongoose.connect(process.env.DB_URL).then(() => {
    console.log("Connect to db");
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/stray/',strayRoutes);
app.use('/api/doctor/',doctorRoutes);
app.get("/",(req,res)=>{
    res.json({
        message:"API is running"
    })
});



app.all("*", (req, res, next) => {
    res.status(404).json({
        message: "Invalid request/ Page not found"
    })
});

app.listen(process.env.PORT, () => {
    console.log(`Server is starting at ${process.env.PORT}`);
});
