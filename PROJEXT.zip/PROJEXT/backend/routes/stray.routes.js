const express = require("express");
const Stray = require("../models/stray.model");
const routes = express.Router();
const upload = require('../util/fileupload')
routes.get("/", (req, res) => {
    res.json({
        message: "Welcome to model",
    });
});

routes.post("/", upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).send({ message: 'No file uploaded' });
        }
        const strayData = {
            name: req.body.name,
            type: req.body.type,
            description: req.body.description,
            imageUrl: req.file.path, 
            location: req.body.location,
            contact: {
                name: req.body.contactName,
                phone: req.body.contactPhone,
                email: req.body.contactEmail,
            },
        };
        const stray = new Stray(strayData);
        await stray.save();
        res.status(201).send(stray);
    } catch (error) {
        res.status(400).send(error);
    }
});
routes.get("/all", async (req, res) => {
    try {
        const strays = await Stray.find();
        res.status(200).send(strays);
    } catch (error) {
        res.status(500).send(error);
    }
})
routes.get("/byId/:id", async (req, res) => {
    try {
        const stray = await Stray.findById(req.params.id);
        if (!stray) {
            return res.status(404).send();
        }
        res.status(200).send(stray);
    } catch (error) {
        res.status(500).send(error);
    }
});



module.exports = routes;