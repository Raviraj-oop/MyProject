const express = require("express");
const Doctor = require("../models/doctor.model");
const routes = express.Router();
routes.get("/", (req, res) => {
    res.json({
        message: "Welcome to model",
    });
});

routes.post("/", async (req, res) => {
    try {
        const doctor = new Doctor(req.body);
        await doctor.save();
        res.status(201).send(doctor);
    } catch (error) {
        res.status(400).send(error);
    }
});
routes.get("/all", async (req, res) => {
    try {
        const doctors = await Doctor.find();
        res.status(200).send(doctors);
    } catch (error) {
        res.status(500).send(error);
    }
})
routes.get("/byId/:id", async (req, res) => {
    try {
        const doctor = await Doctor.findById(req.params.id);
        if (!doctor) {
            return res.status(404).send();
        }
        res.status(200).send(doctor);
    } catch (error) {
        res.status(500).send(error);
    }
});
routes.get("/city", async (req, res) => {
    try {
        const { city } = req.query;
        console.log(city);
        if (!city) {
          return res.status(400).send({ message: 'City query parameter is required' });
        }
        const volunteerDoctors = await Doctor.find({ city: new RegExp(`^${city}$`, 'i') });
        res.status(200).send(volunteerDoctors);
      } catch (error) {
        res.status(500).send({ message: 'Error fetching volunteer doctors', error });
      }
});



module.exports = routes;