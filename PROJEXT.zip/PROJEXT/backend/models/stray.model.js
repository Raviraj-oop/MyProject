
const mongoose = require('mongoose');

const straySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    required: true,
    enum: ['Dog', 'Cat', 'Bird', 'Other'],
  },
  description: {
    type: String,
    required: true,
  },
  imageUrl: {
    type: String, 
    required: true,
  },
  location: {
    type: String, 
    required: true,
  },
  contact: {
    name: {
      type: String,
      required: true,
    },
    phone: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      match: [/.+\@.+\..+/, 'Please enter a valid email address'],
    },
  },
  status: {
    type: String,
    required: true,
    enum: ['Available', 'Adopted', 'In Treatment'],
    default: 'Available',
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
});

const Stray = mongoose.model('Stray', straySchema);

module.exports = Stray;
